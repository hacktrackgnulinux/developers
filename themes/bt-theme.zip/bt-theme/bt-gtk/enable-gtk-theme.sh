#!/bin/bash

zcFP=$(cd "${0%/*}" && pwd);

cd "$zcFP";

source zcsetup/srcscr;

if (test "$1" = "$ResetAllString"); then
	ResetAllGtkThemes;
else
	CheckAndSetupTheme;
	EnableGtkTheme;
fi;

exit
